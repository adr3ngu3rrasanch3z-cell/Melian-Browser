package com.example.novabrowser

import android.view.ViewGroup
import android.graphics.Paint as NativePaint
import android.graphics.Path as NativePath
import android.graphics.PathMeasure
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image
import kotlinx.coroutines.delay

private val Sage = Color(0xFF718875)
private val Ink = Color(0xFF536B67)
private val Cream = Color(0xFFF5F1E8)
private val Sky = Color(0xFFDCEAF0)
private val Pink = Color(0xFFEAD8DF)

@Composable
fun BrowserScreen(state: BrowserState) {
    val tab = state.activeTab
    val isHome = tab == null || tab.url == HOME_URL
    BackHandler(enabled = !isHome && tab?.webView?.canGoBack() == true) { state.goBack() }

    Box(Modifier.fillMaxSize().background(Cream)) {
        if (isHome) {
            MelianHome(state)
        } else {
            tab?.let { current ->
                Column(Modifier.fillMaxSize()) {
                    if (current.progress in 1..99) {
                        LinearProgressIndicator(
                            progress = { current.progress / 100f },
                            modifier = Modifier.fillMaxWidth(),
                            color = Sage,
                            trackColor = Pink
                        )
                    }
                    key(current.id) {
                        AndroidView(
                            modifier = Modifier.fillMaxSize(),
                            factory = {
                                state.getOrCreateWebView(current).apply {
                                    if (parent != null) (parent as? ViewGroup)?.removeView(this)
                                    if (url.isNullOrBlank()) loadUrl(current.url.takeUnless { it == HOME_URL } ?: "https://www.google.com")
                                }
                            },
                            update = {}
                        )
                    }
                }
            }
        }

        // Tabs are a light floating strip at the top, not a bottom toolbar.
        Row(
            Modifier.align(Alignment.TopCenter)
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 9.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            state.tabs.forEach { item ->
                val selected = item.id == state.activeTabId
                Row(
                    Modifier.padding(end = 6.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (selected) Color(0xFFE5E9DF).copy(alpha = .94f) else Color(0xFFF8F3F5).copy(alpha = .82f))
                        .clickable { state.selectTab(item.id) }
                        .padding(start = 11.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (item.url == HOME_URL) "Inicio" else item.title.take(13), color = Ink, fontSize = 12.sp, maxLines = 1)
                    IconButton(onClick = { state.closeTab(item.id) }, modifier = Modifier.size(25.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Cerrar pestaña", tint = Sage, modifier = Modifier.size(14.dp))
                    }
                }
            }
            Box {
                IconButton(
                    onClick = { state.createTab() },
                    modifier = Modifier.size(36.dp).clip(CircleShape).background(Color(0xFFF8F3F5).copy(alpha = .9f))
                ) { Icon(Icons.Default.Add, contentDescription = "Nueva pestaña", tint = Sage) }
            }
        }

        // Independent floating buttons, spaced into the lower corners.
        Row(
            Modifier.align(Alignment.BottomStart).navigationBarsPadding().padding(start = 12.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FloatingNavButton("Atrás", onClick = { state.goBack() }) {
                Image(painterResource(R.drawable.melian_pixel), contentDescription = null, modifier = Modifier.size(29.dp).graphicsLayer(scaleX = -1f))
            }
            FloatingNavButton("Adelante", onClick = { state.goForward() }) {
                Image(painterResource(R.drawable.melian_pixel), contentDescription = null, modifier = Modifier.size(29.dp))
            }
        }

        Row(
            Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 12.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FloatingNavButton("Inicio", onClick = { state.home() }) {
                Icon(Icons.Default.Home, contentDescription = null, tint = Ink, modifier = Modifier.size(23.dp))
            }
            FloatingNavButton("Recargar", onClick = { state.reload() }) {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = Ink, modifier = Modifier.size(23.dp))
            }
            var menuOpen by remember { mutableStateOf(false) }
            Box {
                FloatingNavButton("Menú", onClick = { menuOpen = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = null, tint = Ink, modifier = Modifier.size(23.dp))
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(text = { Text("Nueva pestaña") }, onClick = { menuOpen = false; state.createTab() }, leadingIcon = { Icon(Icons.Default.Add, null) })
                    DropdownMenuItem(text = { Text("Inicio") }, onClick = { menuOpen = false; state.home() }, leadingIcon = { Icon(Icons.Default.Home, null) })
                    DropdownMenuItem(text = { Text("Recargar") }, onClick = { menuOpen = false; state.reload() }, leadingIcon = { Icon(Icons.Default.Refresh, null) })
                    DropdownMenuItem(text = { Text("Pestañas: ${state.tabs.size}") }, onClick = { menuOpen = false })
                }
            }
        }
    }
}

@Composable
private fun FloatingNavButton(label: String, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.size(48.dp).clip(CircleShape)
            .background(Color(0xFFF8F3F5).copy(alpha = .94f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun MelianHome(state: BrowserState) {
    var editing by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFFE5EFF0), Color(0xFFF4E9E9), Color(0xFFE7EBD9))))
            .clickable {
                if (!editing) editing = true
                focus.requestFocus()
            }
    ) {
        // Side-only botanical ornaments: they draw in once, then stay still.
        SideBotanicals(Modifier.fillMaxSize())

        Column(Modifier.fillMaxSize().padding(start = 26.dp, end = 26.dp, top = 58.dp, bottom = 19.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("MELIAN", color = Ink.copy(alpha = .82f), fontSize = 17.sp, fontWeight = FontWeight.Medium, letterSpacing = 2.sp)
                IconButton(onClick = { state.menuExpanded = true }) {
                    Icon(Icons.Default.Menu, contentDescription = "Menú", tint = Ink)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("¿A dónde exploraremos hoy?", color = Ink.copy(alpha = .82f), fontSize = 15.sp, fontFamily = FontFamily.Serif)
            Spacer(Modifier.weight(1f))
            Image(
                painter = painterResource(R.drawable.melian_illustration),
                contentDescription = "Melian, el caballo",
                modifier = Modifier.fillMaxWidth(.88f).weight(5f),
                contentScale = androidx.compose.ui.layout.ContentScale.Fit
            )
            Spacer(Modifier.weight(1f))
            BasicTextField(
                value = state.addressText,
                onValueChange = { state.addressText = it },
                modifier = Modifier.fillMaxWidth(.88f).heightIn(min = 43.dp).focusRequester(focus),
                singleLine = true,
                textStyle = TextStyle(color = Ink, fontSize = 17.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { state.navigate(state.addressText); editing = false }),
                decorationBox = { inner ->
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        if (state.addressText.isEmpty()) Text(if (editing) "Escribe para buscar o visitar..." else "Toca el paisaje para explorar", color = Ink.copy(alpha = .65f), fontSize = 15.sp, fontFamily = FontFamily.Serif)
                        inner()
                    }
                }
            )
            Spacer(Modifier.height(17.dp))
        }

        if (state.menuExpanded) {
            DropdownMenu(expanded = true, onDismissRequest = { state.menuExpanded = false }) {
                DropdownMenuItem(text = { Text("Nueva pestaña") }, onClick = { state.menuExpanded = false; state.createTab() }, leadingIcon = { Icon(Icons.Default.Add, null) })
                DropdownMenuItem(text = { Text("Pestañas: ${state.tabs.size}") }, onClick = { state.menuExpanded = false })
            }
        }
    }
}

@Composable
private fun SideBotanicals(modifier: Modifier = Modifier) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(180)
        progress.animateTo(1f, animationSpec = tween(1500))
    }
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val canvas = drawContext.canvas.nativeCanvas
        val pink = android.graphics.Color.rgb(190, 139, 163)
        val blue = android.graphics.Color.rgb(126, 166, 184)
        val sage = android.graphics.Color.rgb(126, 151, 128)

        fun flourish(mirrorX: Boolean, mirrorY: Boolean, color: Int, delayPart: Float) {
            val sx = if (mirrorX) w else 0f
            val sy = if (mirrorY) h else 0f
            val signX = if (mirrorX) -1f else 1f
            val signY = if (mirrorY) -1f else 1f
            val unit = minOf(w * .34f, h * .30f)
            val path = NativePath().apply {
                moveTo(sx, sy + signY * unit * .10f)
                cubicTo(sx + signX * unit * .10f, sy + signY * unit * .02f,
                    sx + signX * unit * .10f, sy + signY * unit * .30f,
                    sx + signX * unit * .30f, sy + signY * unit * .28f)
                cubicTo(sx + signX * unit * .52f, sy + signY * unit * .25f,
                    sx + signX * unit * .49f, sy + signY * unit * .02f,
                    sx + signX * unit * .34f, sy + signY * unit * .04f)
                cubicTo(sx + signX * unit * .20f, sy + signY * unit * .06f,
                    sx + signX * unit * .23f, sy + signY * unit * .20f,
                    sx + signX * unit * .34f, sy + signY * unit * .19f)
                cubicTo(sx + signX * unit * .43f, sy + signY * unit * .18f,
                    sx + signX * unit * .41f, sy + signY * unit * .10f,
                    sx + signX * unit * .35f, sy + signY * unit * .11f)
                moveTo(sx + signX * unit * .10f, sy + signY * unit * .17f)
                cubicTo(sx + signX * unit * .04f, sy + signY * unit * .36f,
                    sx + signX * unit * .17f, sy + signY * unit * .46f,
                    sx + signX * unit * .28f, sy + signY * unit * .43f)
                cubicTo(sx + signX * unit * .37f, sy + signY * unit * .41f,
                    sx + signX * unit * .37f, sy + signY * unit * .34f,
                    sx + signX * unit * .31f, sy + signY * unit * .34f)
            }
            val localProgress = ((progress.value - delayPart) / (1f - delayPart)).coerceIn(0f, 1f)
            val measure = PathMeasure(path, false)
            val length = measure.length
            val segment = NativePath()
            measure.getSegment(0f, length * localProgress, segment, true)
            val paint = NativePaint(NativePaint.ANTI_ALIAS_FLAG).apply {
                style = NativePaint.Style.STROKE
                strokeWidth = 2.2f
                strokeCap = NativePaint.Cap.ROUND
                strokeJoin = NativePaint.Join.ROUND
                this.color = color
                alpha = 215
            }
            canvas.drawPath(segment, paint)
            if (localProgress >= 1f) {
                val dot = NativePaint(NativePaint.ANTI_ALIAS_FLAG).apply { this.color = color; style = NativePaint.Style.FILL; alpha = 190 }
                canvas.drawCircle(sx + signX * unit * .35f, sy + signY * unit * .11f, 3.1f, dot)
                canvas.drawCircle(sx + signX * unit * .35f, sy + signY * unit * .11f, 6.2f, NativePaint(NativePaint.ANTI_ALIAS_FLAG).apply { this.color = color; style = NativePaint.Style.STROKE; strokeWidth = 1f; alpha = 110 })
            }
        }

        // Four corner flourishes, leaving the horse and search area unobstructed.
        flourish(false, false, pink, 0f)
        flourish(true, false, blue, .12f)
        flourish(false, true, blue, .24f)
        flourish(true, true, pink, .36f)
        val accent = NativePaint(NativePaint.ANTI_ALIAS_FLAG).apply { color = sage; style = NativePaint.Style.STROKE; strokeWidth = 1.5f; alpha = 120 }
        canvas.drawLine(0f, h * .48f, 9f, h * .51f, accent)
        canvas.drawLine(w, h * .52f, w - 9f, h * .55f, accent)
    }
}
